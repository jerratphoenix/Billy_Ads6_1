###############################################################################
# INTEL CONFIDENTIAL                                                          #
#                                                                             #
# Copyright 2021 Intel Corporation.                                           #
#                                                                             #
# This software and the related documents are Intel copyrighted materials,    #
# and your use of them is governed by the express license under which they    #
# were provided to you ("License"). Unless the License provides otherwise,    #
# you may not use, modify, copy, publish, distribute, disclose or transmit    #
# this software or the related documents without Intel's prior written        #
# permission.                                                                 #
#                                                                             #
# This software and the related documents are provided as is, with no express #
# or implied warranties, other than those that are expressly stated in the    #
# License.                                                                    #
###############################################################################


class Region():
    def __init__(self, next):
        self._next = next

    def handle(self, request, report):
        handled = self.processRequest(request, report)
        if not handled:
            self._next.handle(request, report)

    def processRequest(self, request, report):
        pass


class EndOfReport(Region):
    def processRequest(self):
        print("EOR")
        return True
